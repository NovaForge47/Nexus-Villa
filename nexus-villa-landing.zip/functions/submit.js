/**
 * Cloudflare Pages Function: POST /submit  (lead form of the /villa landing page)
 * Delivery. Any ONE success makes the call succeed, so a lead is not lost when one channel is down:
 *   1. Email to info@nexusmedia.biz through Brevo   (secret BREVO_API_KEY)
 *   2. Cloudflare KV                                 (binding LEADS, optional)
 *   3. If BREVO_API_KEY is missing: Web3Forms email  (secret WEB3FORMS_KEY, else the site's public key)
 * Keys never reach the browser. Responds with JSON {ok:true|false}. The existing /api/lead function is untouched.
 */
const TO = 'info@nexusmedia.biz';
const WEB3FORMS_PUBLIC_KEY = '6f49b68f-1bf0-4f23-a77c-19fb158d7758'; // public by design (same key the site forms use)
const json = (obj, status = 200) => new Response(JSON.stringify(obj), { status, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' } });
const clean = (v, max) => String(v ?? '').replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, max);
const esc = (s) => s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const phoneOk = (v) => { const s = v.replace(/[\s\-().]/g, ''); return /^(?:\+30|0030)?(?:69\d{8}|2\d{9})$/.test(s) || /^(?:\+|00)[1-9]\d{7,14}$/.test(s); };
const emailOk = (v) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v);

export async function onRequestPost({ request, env }) {
  let body;
  try { body = await request.json(); } catch { return json({ ok: false, error: 'bad_request' }, 400); }
  if (!body || typeof body !== 'object') return json({ ok: false, error: 'bad_request' }, 400);

  /* honeypot: pretend success, store nothing */
  if (clean(body.website, 100)) return json({ ok: true });

  const lead = {
    name: clean(body.name, 120),
    phone: clean(body.phone, 40),
    email: clean(body.email, 160),
    timestamp: new Date().toISOString(),
    utm_source: clean(body.utm_source, 200),
    utm_medium: clean(body.utm_medium, 200),
    utm_campaign: clean(body.utm_campaign, 200),
    utm_content: clean(body.utm_content, 200),
    fbclid: clean(body.fbclid, 300),
  };
  if (lead.name.length < 2 || !phoneOk(lead.phone) || (lead.email && !emailOk(lead.email)) || body.consent !== true) {
    return json({ ok: false, error: 'invalid' }, 422);
  }
  if (Number(body.elapsed_ms) < 1500) return json({ ok: true }); /* far too fast to be a person */

  const lines = [
    ['Όνομα', lead.name], ['Τηλέφωνο', lead.phone], ['Email', lead.email || '-'], ['Ώρα (UTC)', lead.timestamp],
    ['utm_source', lead.utm_source || '-'], ['utm_medium', lead.utm_medium || '-'], ['utm_campaign', lead.utm_campaign || '-'], ['utm_content', lead.utm_content || '-'], ['fbclid', lead.fbclid || '-'],
  ];
  const subject = `ΝΕΟ LEAD: ${lead.name} ${lead.phone}`;
  const text = lines.map(([k, v]) => `${k}: ${v}`).join('\n');
  let delivered = false;

  if (env.BREVO_API_KEY) {
    try {
      const res = await fetch('https://api.brevo.com/v3/smtp/email', {
        method: 'POST',
        headers: { 'api-key': env.BREVO_API_KEY, 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({
          sender: { name: 'Nexus Media site', email: env.SENDER_EMAIL || TO },
          to: [{ email: env.NOTIFY_EMAIL || TO }],
          ...(lead.email ? { replyTo: { email: lead.email, name: lead.name } } : {}),
          subject,
          htmlContent: `<h2>${esc(subject)}</h2><table>${lines.map(([k, v]) => `<tr><td><b>${esc(k)}</b></td><td>${esc(v)}</td></tr>`).join('')}</table>`,
          textContent: text,
        }),
      });
      if (res.ok) delivered = true; else console.error('brevo failed', res.status);
    } catch (err) { console.error('brevo error', String(err)); }
  }
  /* Email through Web3Forms is sent by the browser (script.js): Web3Forms refuses server-side calls on its free plan. */

  if (env.LEADS && typeof env.LEADS.put === 'function') {
    try { await env.LEADS.put(`lead:${lead.timestamp}:${crypto.randomUUID()}`, JSON.stringify(lead)); delivered = true; }
    catch (err) { console.error('kv error', String(err)); }
  }

  return delivered ? json({ ok: true }) : json({ ok: false, error: 'delivery' }, 502);
}

export const onRequest = () => json({ ok: false, error: 'method' }, 405);
