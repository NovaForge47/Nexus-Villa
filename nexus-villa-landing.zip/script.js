/* Small vanilla script. Without it the page still shows and the form posts natively. */
(function () {
  'use strict';
  var PIXEL_ID = 'PIXEL_ID_HERE';      /* TODO: your Meta Pixel ID */
  var WEB3FORMS_KEY = '6f49b68f-1bf0-4f23-a77c-19fb158d7758'; /* public by design */
  var HOURS = '9:00-21:00';            /* ΩΡΕΣ_ΛΕΙΤΟΥΡΓΙΑΣ */
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var store = {
    get: function (k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
    set: function (k, v) { try { localStorage.setItem(k, v); } catch (e) { /* private mode */ } },
    sget: function (k) { try { return sessionStorage.getItem(k); } catch (e) { return null; } },
    sset: function (k, v) { try { sessionStorage.setItem(k, v); } catch (e) { /* private mode */ } }
  };

  if (HOURS) { var h = $('#hours'); if (h) h.textContent = ' (' + HOURS + ')'; }

  /* Founder video: show the section only when the file really exists (a host may answer 200 with index.html) */
  var vsec = $('#video'), vid = vsec && $('video', vsec);
  if (vid && window.fetch) {
    var src = vid.getAttribute('data-media');
    fetch(src, { method: 'HEAD' }).then(function (r) {
      if (r.ok && (r.headers.get('content-type') || '').indexOf('video') === 0) { vid.src = src; vsec.hidden = false; }
    }).catch(function () { /* stays hidden */ });
  }

  /* "Καλέστε με": scroll to the form and focus the first field */
  $$('a[data-cta]').forEach(function (a) {
    a.addEventListener('click', function (e) {
      var t = $('#form'); if (!t) return;
      e.preventDefault();
      var calm = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      t.scrollIntoView({ behavior: calm ? 'auto' : 'smooth', block: 'start' });
      setTimeout(function () { var n = $('#f-name'); if (n) n.focus({ preventScroll: true }); }, 450);
    });
  });

  /* UTM + fbclid, first touch of the session wins */
  var keys = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'fbclid'];
  var params = new URLSearchParams(location.search);
  var attr = {};
  try { attr = JSON.parse(store.sget('nx_attr') || '{}'); } catch (e) { attr = {}; }
  keys.forEach(function (k) { var v = params.get(k); if (v) attr[k] = v.slice(0, 200); });
  store.sset('nx_attr', JSON.stringify(attr));
  var form = $('#lead-form');
  if (form) keys.forEach(function (k) { if (attr[k] && form.elements[k]) form.elements[k].value = attr[k]; });

  /* Meta Pixel: only after "Αποδοχή". PageView on load, Lead on success, Contact on WhatsApp click */
  var pixelOn = false;
  function loadPixel() {
    if (pixelOn || !PIXEL_ID || PIXEL_ID === 'PIXEL_ID_HERE') return;
    pixelOn = true;
    !function (f, b, e, v, n, t, s) { if (f.fbq) return; n = f.fbq = function () { n.callMethod ? n.callMethod.apply(n, arguments) : n.queue.push(arguments); }; if (!f._fbq) f._fbq = n; n.push = n; n.loaded = !0; n.version = '2.0'; n.queue = []; t = b.createElement(e); t.async = !0; t.src = v; s = b.getElementsByTagName(e)[0]; s.parentNode.insertBefore(t, s); }(window, document, 'script', 'https://connect.facebook.net/en_US/fbevents.js');
    window.fbq('init', PIXEL_ID);
    window.fbq('track', 'PageView');
  }
  function track(name) { try { if (pixelOn && window.fbq) window.fbq('track', name); } catch (e) { /* ignore */ } }

  loadPixel(); /* no cookie banner: stays inactive until a real PIXEL_ID is set */

  document.addEventListener('click', function (e) {
    var a = e.target.closest && e.target.closest('a[data-wa]');
    if (a) track('Contact');
  });

  /* Lead form */
  if (!form) return;
  var f = form.elements;
  var statusEl = $('#f-status'), btn = $('#f-submit');
  var started = Date.now();

  /* Greek (+30 optional; 69xxxxxxxx mobile or 2xxxxxxxxx landline) or international (+ or 00, 8 to 15 digits) */
  function phoneOk(v) {
    var s = String(v).replace(/[\s\-().]/g, '');
    return /^(?:\+30|0030)?(?:69\d{8}|2\d{9})$/.test(s) || /^(?:\+|00)[1-9]\d{7,14}$/.test(s);
  }
  function setErr(id, field, msg) {
    var el = $('#' + id);
    if (el) el.textContent = msg;
    if (field) { if (msg) field.setAttribute('aria-invalid', 'true'); else field.removeAttribute('aria-invalid'); }
  }
  function validate() {
    var ok = true, first = null;
    function bad(field) { ok = false; if (!first) first = field; }
    if (f.name.value.trim().length < 2) { setErr('e-name', f.name, 'Γράψε το όνομά σου.'); bad(f.name); } else setErr('e-name', f.name, '');
    if (!phoneOk(f.phone.value)) { setErr('e-phone', f.phone, 'Γράψε ένα έγκυρο τηλέφωνο, π.χ. 6912345678 ή +44 7700 900123.'); bad(f.phone); } else setErr('e-phone', f.phone, '');
    if (!f.consent.checked) { setErr('e-consent', f.consent, 'Χρειάζεται η συναίνεσή σου για να σε καλέσουμε.'); bad(f.consent); } else setErr('e-consent', f.consent, '');
    if (first && first.focus) first.focus();
    return ok;
  }
  ['name', 'phone'].forEach(function (n) { f[n].addEventListener('input', function () { if (f[n].getAttribute('aria-invalid')) validate(); }); });

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    statusEl.textContent = '';
    if (!validate()) return;

    var payload = {
      name: f.name.value.trim(),
      phone: f.phone.value.trim(),
      website: f.website.value, /* honeypot */
      consent: true,
      elapsed_ms: Date.now() - started,
      page: location.pathname
    };
    keys.forEach(function (k) { payload[k] = (f[k] && f[k].value) || ''; });

    btn.disabled = true;
    var label = btn.textContent;
    btn.textContent = 'Στέλνουμε…';
    var finish = function (ok) {
      btn.disabled = false;
      btn.textContent = label;
      if (ok) {
        $('.fields', form).hidden = true;
        var s = $('#f-success'); s.hidden = false; s.focus();
        track('Lead');
      } else {
        statusEl.textContent = 'Δεν στάλθηκε η φόρμα. Τα στοιχεία σου είναι ακόμα εδώ. Δοκίμασε ξανά ή γράψε μας στο WhatsApp.';
      }
    };

    /* 1) Web3Forms from the browser (email to the inbox; its free plan only accepts browser calls)
       2) /submit stores a copy in Cloudflare KV. The visitor sees success if either one works. */
    var lines = ['Όνομα: ' + payload.name, 'Τηλέφωνο: ' + payload.phone];
    keys.forEach(function (k) { lines.push(k + ': ' + (payload[k] || '-')); });
    var w3 = { access_key: WEB3FORMS_KEY, subject: 'ΝΕΟ LEAD: ' + payload.name + ' ' + payload.phone, from_name: 'Nexus Media villa page', name: payload.name, phone: payload.phone, message: lines.join('\n'), botcheck: '' };
    var post = function (url, data) {
      var ctrl = window.AbortController ? new AbortController() : null;
      var to = setTimeout(function () { if (ctrl) ctrl.abort(); }, 12000);
      return fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }, body: JSON.stringify(data), signal: ctrl ? ctrl.signal : undefined })
        .then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) { clearTimeout(to); return r.ok && j.success !== false && j.ok !== false; }); })
        .catch(function () { clearTimeout(to); return false; });
    };
    var spam = !!payload.website; /* honeypot filled: act like success, send nothing */
    if (spam) { finish(true); return; }
    Promise.all([post('https://api.web3forms.com/submit', w3), post(form.getAttribute('action') || '/submit', payload)]).then(function (res) { finish(res[0] || res[1]); });
  });
})();
